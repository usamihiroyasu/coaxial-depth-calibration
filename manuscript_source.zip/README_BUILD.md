# Build the manuscript

Use a current LaTeX installation with the packages named in `manuscript.tex`, including siunitx, TikZ and PGFplots. The Springer class and bibliography style are included. Run `pdflatex -halt-on-error manuscript.tex` twice from this directory. Figure PDFs are included. The numerical inputs and figure sources are in Online Resource 1.
