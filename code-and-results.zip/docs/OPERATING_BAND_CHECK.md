# An operating-band check for isotropic illumination

Let all source radii satisfy `0 < r_i <= r_max`, and let the calibrated unit normal satisfy `||b||/nu <= T`, with `nu > 0` and `T >= 0`. Source coefficients are positive and gain is positive. For a band `0 < z_min < z_max`, define

$$t_{\mathrm{dec}}(T)=\frac{3T+\sqrt{9T^2+8}}4.$$

If `z_min >= r_max * t_dec(T)`, the isotropic response is strictly decreasing on the band with zero coaxial coefficient. This is a direct consequence of the derivative formula in manuscript Eq. (6).

Put `d = sqrt(9T^2 + 8)`. The quadratic `q(t) = 1 - 2t^2 + 3Tt` satisfies `q(t_dec) = 0`, since `8 q(t_dec) = 8 + 9T^2 - d^2 = 0`. Also `t_dec > T` and `q'(t) <= -d < 0` for `t >= t_dec`. Each source is lit, and its derivative numerator is at most `q(t)` because its normalized transverse offset is at least `-T`. At every interior depth `z > z_min`, the derivative is strictly negative. Summing positive source coefficients preserves this sign.

The condition provides a sufficient monotonicity check on a specified band. It does not assert sharpness for every band or a uniform inverse-error bound at its endpoint. At `T = 1`, the cutoff is approximately `1.7808`, to five significant figures. Full-precision root enclosures are retained in `code/operating_band/BAND_CHECK.json`.

From the archive root, run:

```sh
python3 code/operating_band/verify_band_check.py --output reproduced/BAND_CHECK.json
```

The output must be new. The command checks exact rational root enclosures and slope signs at `T = 0, 1, 8, 64`; the continuum statement follows from the algebra above.
