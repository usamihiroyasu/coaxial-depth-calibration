# Lighting animation

The 3D scene and fixed-scale response plots illustrate the flat-normal scalar calibration model. Depth drives the geometric surface point and both graph cursors. The three stages use source ratios of 0.8, 1, and 1.2 times the critical ratio.

Re-render on macOS with Swift, LaTeX, and FFmpeg installed:

```sh
zsh reproduce.sh
```

The script prints the directory containing the GIF and silent MP4. Equation cards are typeset with LaTeX.
