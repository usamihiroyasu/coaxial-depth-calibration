"""Projection and cursor synchronization checks for the explanatory scene."""
import json, math
s=96
p=[[math.sqrt(3)*s/2,-math.sqrt(3)*s/2,0],[-s/2,-s/2,s]]
dot=lambda a,b:sum(x*y for x,y in zip(a,b))
assert abs(dot(p[0],p[1]))<1e-12
assert abs(dot(p[0],p[0])-dot(p[1],p[1]))<1e-10
axis_lengths=[math.hypot(p[0][j],p[1][j]) for j in range(3)]
assert max(abs(v-s) for v in axis_lengths)<1e-12
depths=[1+.25*math.sin(2*math.pi*(f%90)/89) for f in range(270)]
assert min(depths)>=.75 and max(depths)<=1.25
for z in depths:
    assert abs(((350+s*z)-350)/s-z)<1e-15
    assert abs(((660+(z-.5)/2.5*845)-660)/845*2.5+.5-z)<1e-15
    assert abs(((660+(z-.7)/.6*845)-660)/845*.6+.7-z)<1e-15
print(json.dumps({'projection':'orthographic isometric, equal projected axis lengths',
 'matrix':p,'projected_axis_lengths':axis_lengths,'normal_world':[0,0,-1],
 'camera_and_coaxial_world':[0,0,0],'offaxis_source_world':[2,0,0],
 'surface_world':'(0,0,z)','depth_extrema':[min(depths),max(depths)],
 'shared_geometry_and_graph_cursor_depth_checks':270,'status':'PASSED'},indent=2))
