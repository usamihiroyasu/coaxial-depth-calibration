#!/bin/zsh
set -euo pipefail
asset_dir=${0:A:h}
render_dir=$(mktemp -d "${TMPDIR:-/tmp}/lighting-animation-v2.XXXXXX")
mkdir "$render_dir/formula"
for card in response act0 act1 act2; do
  pdflatex -interaction=batchmode -halt-on-error -output-directory "$render_dir/formula" "$asset_dir/formula/$card.tex" > /dev/null
done
swiftc -module-cache-path "$render_dir/module_cache" "$asset_dir/render.swift" -o "$render_dir/render"
"$render_dir/render" "$render_dir/frames" "$render_dir/formula"
ffmpeg -n -hide_banner -v error -framerate 15 -i "$render_dir/frames/frame_%04d.png" -an -c:v libx264 -crf 18 -pix_fmt yuv420p -movflags +faststart "$render_dir/lighting_thresholds_3d_silent.mp4"
ffmpeg -n -hide_banner -v error -i "$render_dir/lighting_thresholds_3d_silent.mp4" -vf 'fps=15,palettegen=max_colors=192:stats_mode=diff' -frames:v 1 "$render_dir/palette.png"
ffmpeg -n -hide_banner -v error -i "$render_dir/lighting_thresholds_3d_silent.mp4" -i "$render_dir/palette.png" -lavfi 'fps=15[x];[x][1:v]paletteuse=dither=sierra2_4a:diff_mode=rectangle' -loop 0 "$render_dir/lighting_thresholds_3d.gif"
python3 "$asset_dir/verify_formula.py"
python3 "$asset_dir/verify_geometry.py"
printf 'Rendered files: %s\n' "$render_dir"
