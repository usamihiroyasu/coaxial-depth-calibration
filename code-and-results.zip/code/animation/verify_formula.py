"""Formula-only checks; optional existing response.csv comparison, no model experiment."""
import csv, hashlib, json, math, pathlib, sys
c0 = 1 / (25 * math.sqrt(5))
def phi(z, m): return m / z**2 + z / (z*z + 4)**1.5
def scaled_derivative(z, m): return -2*m + z**3*(4-2*z*z)/(z*z+4)**2.5
def second(z, m): return 6*m/z**4 + 3*z*(2*z*z-12)/(z*z+4)**3.5
def third(z, m):
    return -24*m/z**5 + (18*z*z-36)/(z*z+4)**3.5 - 7*z*(6*z**3-36*z)/(z*z+4)**4.5
checks = {
    'c0': c0, 'phi_at_critical': phi(1,c0),
    'scaled_derivative_at_z1': [scaled_derivative(1,f*c0) for f in [.8,1,1.2]],
    'critical_second_derivative': second(1,c0),
    'critical_third_derivative': third(1,c0),
    'above_margin_sufficient_abs_derivative_bound_on_band': 2*.2*c0/3**3,
}
assert checks['scaled_derivative_at_z1'][0] > 0
assert abs(checks['scaled_derivative_at_z1'][1]) < 1e-15
assert checks['scaled_derivative_at_z1'][2] < 0
assert abs(phi(1,c0)-6/(25*math.sqrt(5))) < 1e-15
assert abs(second(1,c0)) < 1e-15
assert abs(third(1,c0)+96/(125*math.sqrt(5))) < 1e-14
if len(sys.argv) > 1:
    p=pathlib.Path(sys.argv[1]); rows=list(csv.DictReader(p.open()))
    err=max(abs(float(r[k])-scaled_derivative(float(r['depth']),f*c0))
            for r in rows for k,f in [('below',.8),('critical',1),('above',1.2)])
    assert err < 1e-13
    checks['existing_csv_comparison']={'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
        'rows':len(rows),'max_abs_error':err,'meaning':'same existing scaled-derivative curves'}
checks['status']='FORMULA_CHECKS_PASSED'
print(json.dumps(checks,indent=2))
