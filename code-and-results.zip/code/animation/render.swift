import AppKit
import Foundation
let W=1600,H=900,fps=15,count=270
let out=CommandLine.arguments[1], pdfdir=CommandLine.arguments[2]
let navy=NSColor(calibratedRed:0.08,green:0.16,blue:0.26,alpha:1), blue=NSColor(calibratedRed:0,green:0.45,blue:0.70,alpha:1), orange=NSColor(calibratedRed:0.84,green:0.27,blue:0.02,alpha:1)
let gray=NSColor(calibratedRed:0.48,green:0.55,blue:0.62,alpha:1), grid=NSColor(calibratedRed:0.88,green:0.91,blue:0.94,alpha:1), bg=NSColor(calibratedRed:0.96,green:0.975,blue:0.99,alpha:1)
let colors=[orange,navy,blue],factors=[0.8,1.0,1.2],c0=1.0/(25.0*sqrt(5.0))
func rect(_ x:Double,_ y:Double,_ w:Double,_ h:Double)->NSRect {NSRect(x:x,y:Double(H)-y-h,width:w,height:h)}
func pt(_ x:Double,_ y:Double)->NSPoint {NSPoint(x:x,y:Double(H)-y)}
func text(_ s:String,_ x:Double,_ y:Double,_ w:Double,_ size:Double=22,_ weight:NSFont.Weight = .regular,_ color:NSColor?=nil){let p=NSMutableParagraphStyle();p.lineBreakMode = .byClipping;(s as NSString).draw(in:rect(x,y,w,size*1.65),withAttributes:[.font:NSFont.systemFont(ofSize:size,weight:weight),.foregroundColor:color ?? navy,.paragraphStyle:p])}
func line(_ x:Double,_ y:Double,_ a:Double,_ b:Double,_ color:NSColor,_ width:Double=1){let p=NSBezierPath();p.move(to:pt(x,y));p.line(to:pt(a,b));p.lineWidth=width;color.setStroke();p.stroke()}
func circle(_ x:Double,_ y:Double,_ r:Double,_ color:NSColor,_ fill:Bool=true){let p=NSBezierPath(ovalIn:rect(x-r,y-r,2*r,2*r));p.lineWidth=2.5;if fill{color.setFill();p.fill()}else{color.setStroke();p.stroke()}}
func card(_ x:Double,_ y:Double,_ w:Double,_ h:Double){NSColor.white.setFill();NSBezierPath(roundedRect:rect(x,y,w,h),xRadius:16,yRadius:16).fill()}
func phi(_ z:Double,_ m:Double)->Double {m/(z*z)+z/pow(z*z+4,1.5)}
func d(_ z:Double,_ m:Double)->Double {-2*m+pow(z,3)*(4-2*z*z)/pow(z*z+4,2.5)}
func xy(_ z:Double,_ v:Double,_ r:[Double],_ xr:[Double],_ yr:[Double])->NSPoint {pt(r[0]+(z-xr[0])/(xr[1]-xr[0])*r[2],r[1]+r[3]-(v-yr[0])/(yr[1]-yr[0])*r[3])}
func curve(_ m:Double,_ rr:[Double],_ xr:[Double],_ yr:[Double],_ deriv:Bool,_ color:NSColor,_ width:Double){let p=NSBezierPath();for i in 0...400{let z=xr[0]+Double(i)/400*(xr[1]-xr[0]);let v=deriv ? d(z,m):phi(z,m);let a=xy(z,v,rr,xr,yr);if i==0{p.move(to:a)}else{p.line(to:a)}};p.lineWidth=width;p.lineJoinStyle = .round;color.setStroke();p.stroke()}
func axis(_ r:[Double],_ xr:[Double],_ yr:[Double],_ xt:[Double],_ yt:[Double]){for z in xt{let x=r[0]+(z-xr[0])/(xr[1]-xr[0])*r[2];line(x,r[1],x,r[1]+r[3],grid);text(String(format:"%.1f",z),x-17,r[1]+r[3]+9,54,17,.regular,gray)};for v in yt{let y=r[1]+r[3]-(v-yr[0])/(yr[1]-yr[0])*r[3];line(r[0],y,r[0]+r[2],y,grid);text(String(format:"%.3f",v),r[0]-64,y-11,59,17,.regular,gray)};line(r[0],r[1]+r[3],r[0]+r[2],r[1]+r[3],gray,1.3);line(r[0],r[1],r[0],r[1]+r[3],gray,1.3)}

func polygon(_ points:[NSPoint],_ color:NSColor){let p=NSBezierPath();p.move(to:points[0]);for a in points.dropFirst(){p.line(to:a)};p.close();color.setFill();p.fill();gray.withAlphaComponent(0.4).setStroke();p.lineWidth=1;p.stroke()}
func pdf(_ name:String,_ x:Double,_ y:Double,_ w:Double,_ h:Double){let im=NSImage(contentsOfFile:pdfdir+"/"+name+".pdf")!;let s=min(w/im.size.width,h/im.size.height);let iw=im.size.width*s,ih=im.size.height*s;im.draw(in:rect(x+(w-iw)/2,y+(h-ih)/2,iw,ih))}
let resp=[660.0,294,845,225],der=[660.0,665,845,120],rx=[0.5,3.0],ry=[0.05,0.15],dx=[0.7,1.3],dy=[-0.03,0.01]
let titles=["BELOW THE THRESHOLD","AT THE THRESHOLD","A STABLE MARGIN"]
let insights=["A rising segment: depth is ambiguous","Unique depth; flat point at z = 1","Nonzero slope across the depth band"]
try FileManager.default.createDirectory(atPath:out,withIntermediateDirectories:true)
for f in 0..<count {autoreleasepool {
 let act=f/90,u=Double(f%90)/89,z=1+0.25*sin(2*Double.pi*u),m=factors[act]*c0,color=colors[act]
 let rep=NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:W,pixelsHigh:H,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!;rep.size=NSSize(width:W,height:H)
 NSGraphicsContext.saveGraphicsState();NSGraphicsContext.current=NSGraphicsContext(bitmapImageRep:rep);bg.setFill();rect(0,0,Double(W),Double(H)).fill()
 text("Illumination Balance and Sharp Thresholds",40,17,1520,38,.semibold);text("for Near-Field Depth Calibration",40,60,1520,35,.semibold)
 text("Hiroyasu Usami  ·  Ayato Tsuboi  ·  Keisuke Hara",42,111,1500,24,.regular,gray)
 for i in 0...2 {let x=40.0+Double(i)*510;let r=rect(x,157,495,45);(i==act ? colors[i] : NSColor.white).setFill();NSBezierPath(roundedRect:r,xRadius:9,yRadius:9).fill();text(String(format:"%02d  ",i+1)+titles[i],x+16,164,468,22,.semibold,i==act ? .white:gray);let w=495*(i<act ? 1:i==act ? u:0);if w>0{colors[i].setFill();rect(x,206,w,3).fill()}}
 card(40,220,510,612);card(575,220,985,350);card(575,594,985,238)
 text("3D light geometry",62,234,370,24,.semibold)
 let ox=244.0,oy=350.0,scale=96.0
 func iso(_ x:Double,_ y:Double,_ a:Double)->NSPoint{pt(ox+sqrt(3)/2*scale*(x-y),oy+scale*(a-(x+y)/2))}
 let o=iso(0,0,0),src=iso(2,0,0),surface=iso(0,0,z)
 polygon([iso(-0.7,-0.7,0),iso(0.7,-0.7,0),iso(0.7,0.7,0),iso(-0.7,0.7,0)],blue.withAlphaComponent(0.10))
 polygon([iso(-0.34,-0.34,z),iso(0.34,-0.34,z),iso(0.34,0.34,z),iso(-0.34,0.34,z)],gray.withAlphaComponent(0.12))
 for a in [iso(1.0,0,0),iso(0,1.0,0)]{line(Double(o.x),Double(H)-Double(o.y),Double(a.x),Double(H)-Double(a.y),gray.withAlphaComponent(0.45),1.2)}
 line(ox,oy,Double(src.x),Double(H)-Double(src.y),gray,1.5);line(ox,oy,Double(surface.x),Double(H)-Double(surface.y),color,2.5);line(Double(src.x),Double(H)-Double(src.y),Double(surface.x),Double(H)-Double(surface.y),orange.withAlphaComponent(0.8),2)
 circle(ox,oy,10,color);circle(Double(src.x),Double(H)-Double(src.y),10,orange);circle(Double(surface.x),Double(H)-Double(surface.y),6.5,navy)
 let py=Double(H)-Double(surface.y);line(ox,py,ox,py-45,blue,3);line(ox,py-45,ox-6,py-35,blue,2);line(ox,py-45,ox+6,py-35,blue,2)
 text("Camera + coaxial",62,320,218,19,.medium);text("source",62,342,140,19,.medium);text("Off-axis source",354,274,183,19,.medium);text("r = 2",328,310,115,20,.medium,gray);text("z = 0 plane",328,390,190,18,.regular,gray);text("surface normal n",75,py-48,164,19,.medium,blue);text(String(format:"z = %.2f",z),263,py-10,170,22,.medium)
 pdf("response",65,510,460,75);pdf("act\(act)",65,592,460,60)
 text("z  surface depth",65,674,455,21);text("r  off-axis source offset",65,701,455,21);text("m₀  coaxial strength",65,728,455,21);text("S  total off-axis strength",65,755,455,21);text("Φ  predicted brightness",65,782,455,21)
 text(insights[act],598,238,930,27,.semibold,color)
 axis(resp,rx,ry,[0.5,1,1.5,2,2.5,3],[0.05,0.1,0.15]);for i in 0...2{curve(factors[i]*c0,resp,rx,ry,false,gray.withAlphaComponent(0.20),2)};curve(m,resp,rx,ry,false,color,4)
 let a=xy(z,phi(z,m),resp,rx,ry);circle(Double(a.x),Double(H)-Double(a.y),7,color);text("Depth z (model units)",1200,540,345,20,.regular,gray);text("Φ(z)",601,317,65,23,.medium,gray)
 text("Scaled derivative  z³Φ′(z)",598,609,770,26,.semibold);axis(der,dx,dy,[0.7,0.8,1,1.2,1.3],[-0.03,-0.01,0,0.01]);let zero=xy(0.7,0,der,dx,dy);line(der[0],Double(H)-Double(zero.y),der[0]+der[2],Double(H)-Double(zero.y),navy.withAlphaComponent(0.55),1.6)
 for i in 0...2{curve(factors[i]*c0,der,dx,dy,true,gray.withAlphaComponent(0.22),1.8)};curve(m,der,dx,dy,true,color,4);let b=xy(z,d(z,m),der,dx,dy);circle(Double(b.x),Double(H)-Double(b.y),6,color)
 if act==1{let k=xy(1,0,der,dx,dy);circle(Double(k.x),Double(H)-Double(k.y),10,navy,false)}
 text("0.7 ≤ z ≤ 1.3 · fixed scale",1185,616,345,18,.regular,gray)
 text("Ideal model · front-facing surface · calibrated gain · S = 1 · depth band 0.5–3",40,861,1520,22,.regular,gray)
 NSGraphicsContext.restoreGraphicsState();let data=rep.representation(using:.png,properties:[:])!;try! data.write(to:URL(fileURLWithPath:String(format:"%@/frame_%04d.png",out,f)),options:.atomic)
}}
print("rendered \(count) frames \(W)x\(H)")
