"""Fixed20-observation packaging reproduction; known calibrated isotropic case only."""
from pathlib import Path
from decimal import Decimal,localcontext
import argparse,json,hashlib,os
SPEC_SHA256 = "2b3ddc41a41df5afa02ce7753e23312c4758c71ec5bf7a3fa658434d8b7559b1"

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',type=Path,required=True,help='New directory; any existing path is refused.')
    parser.add_argument('--spec',type=Path,default=Path(__file__).with_name('SPEC.json'),help='Byte-identical frozen SPEC.json.')
    args=parser.parse_args()
    raw=args.spec.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=SPEC_SHA256:
        parser.error('SPEC SHA256 mismatch: only the bundled fixed case is supported.')
    s=json.loads(raw);O=args.output_dir
    try: O.mkdir(mode=0o700,exist_ok=False)
    except FileExistsError: parser.error('Output path already exists; no files were changed.')
    rows=[]
    with localcontext() as ctx:
     ctx.prec=s['decimal_precision'];D=Decimal;nu=1/D(2).sqrt();c=1/(4*D(2).sqrt());eps=D(s['intensity_noise_cap']);delta=D(s['target_depth_error']);zlo,zhi=map(D,s['depth_band']);eta=zhi**3*eps/(2*nu*delta);m0s={'threshold':c,'accuracy_design':c+eta};L=zhi**3/(2*nu*eta)
     def direct(z,m):
      distance=(D(4)+z*z).sqrt();incidence=max((-nu*D(2)+(-nu)*(-z))/distance,D(0));coaxincidence=(-nu)*(-z)/z;return m*coaxincidence/(z*z)+incidence/(distance*distance)
     def reduced(z,m):return nu*m/(z*z)+max(nu*(z-D(2)),D(0))/((z*z+D(4))*(z*z+D(4)).sqrt())
     def recover(y,m):
      upper=reduced(zlo,m);lower=reduced(zhi,m);target=min(max(y,lower),upper);a,b=zlo,zhi
      for _ in range(300):
       mid=(a+b)/2
       if mid==a or mid==b:break
       if reduced(mid,m)>target:a=mid
       else:b=mid
      return (a+b)/2,target!=y
     for name,m in m0s.items():
      for zz in s['depths']:
       z=D(zz);true=direct(z,m);assert abs(true-reduced(z,m))<D('1e-75')
       for sign in s['noise_signs']:
        noisy=true+sign*eps;got,clipped=recover(noisy,m);error=abs(got-z);rows.append({'scheme':name,'m0':str(m),'true_depth':str(z),'noise':str(sign*eps),'recovered_depth':str(got),'absolute_error':str(error),'endpoint_clipped':clipped,'target_met':error<=delta+D('1e-70')})
     assert len(rows)==20 and all(r['target_met'] for r in rows if r['scheme']=='accuracy_design');summary={'state':'FIXED_MODEL_DESIGN_CONTROL_PASS','precision':ctx.prec,'c1':str(c),'eta_absolute_coefficient':str(eta),'design_m0':str(c+eta),'offaxis_S':'1','uniform_inverse_L':str(L),'noise_bound':str(eps),'guaranteed_depth_error':str(L*eps),'rows':20,'scheme_summary':{name:{'max_error':str(max(D(r['absolute_error']) for r in rows if r['scheme']==name)),'target_met_rows':sum(r['target_met'] for r in rows if r['scheme']==name),'rows':10} for name in m0s},'optical_measurement_or_model_training':False,'new_theory_claim':False,'known_normal_gain_and_ideal_radiometry_required':True}
    def write_new(name,data):
        fd=os.open(O/name,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        with os.fdopen(fd,'wb') as f:
            f.write(data)
    write_new('ROWS.json',(json.dumps(rows,indent=2)+'\n').encode())
    write_new('SUMMARY.json',(json.dumps(summary,indent=2)+'\n').encode())
    write_new('SPEC.json',raw)
    write_new('design_case.py',Path(__file__).read_bytes())
    print(json.dumps(summary))

if __name__=='__main__':
    main()
