# Coefficient-selection example

Use Python 3 on a POSIX system, with its standard library:

```sh
python3 design_case.py --output-dir design_case_reproduced
```

The destination must be new and its parent must exist. The bundled `SPEC.json` defines the calibrated normal, source, depth band, noise bound, and target depth error. The CLI checks this input by SHA-256.

`ROWS.json` contains 20 observations and `SUMMARY.json` compares the threshold-only and strict-margin designs. All coefficients and depths use model units.
