import json
from radiometry import normal,critical,derivative,irradiance3d,reduced
from pathlib import Path
layouts=[[(2,0,.5),(-2,0,.5)],[(2,0,.25),(-2,0,.25),(0,2,.25),(0,-2,.25)]]
rows=[]
for T in [0,.5,1,2]:
 for j,off in enumerate(layouts):
  for z in [.5,.75,1.25,2.5,5]:
   n=normal(T);c=critical(0);lights=off+[(0,0,1.2*c)]
   residual=derivative(z,n,lights)*z**3/(-n[2])+2*.2*c
   error=abs(irradiance3d(z,n,lights)-reduced(z,n,lights))
   assert residual<=1e-12 and error<=1e-12
   rows.append({'T':T,'layout':j,'z':z,'gap_residual':residual,'3D_error':error})
Path(__file__).with_name('BALANCED_RESULTS.json').write_text(json.dumps({'status':'PASS','cases':rows,'case_count':len(rows),'frozen_before_execution':True,'captured_optical_data':False},indent=2)+'\n')
print('BALANCED40_PASS')
