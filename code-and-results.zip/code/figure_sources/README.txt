Vector figure sources use standalone, TikZ, and PGFplots. Run pdflatex -halt-on-error figure1.tex in this directory and compile figure2.tex and figure3.tex similarly. CSV inputs contain the numerical curves shown in the manuscript.
figure4.tex: fixed-budget allocation and bounded normal/gain calibration error; budget_curve.csv and mismatch_curve.csv.
