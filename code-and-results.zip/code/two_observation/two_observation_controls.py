"""Fixed-budget two-observation depth controls and a clamping collision."""
from pathlib import Path
from decimal import Decimal as D, getcontext, localcontext, ROUND_CEILING
from math import isqrt
from itertools import product
import argparse, csv, hashlib, json, shutil

getcontext().prec = 80
ONE, ZERO = D(1), D(0)

def root(value, k):
    if value == 0:
        return ZERO
    x = ONE
    for _ in range(300):
        x = ((k-1)*x + value/x**(k-1))/k
    return x

def forward(z, n, gain, mu, m0, off, layout):
    result = gain*m0*(-n[2])/z**2
    for ax, ay in layout:
        dist = (ax*ax+ay*ay+z*z).sqrt()
        cosine = max((n[0]*ax+n[1]*ay-n[2]*z)/dist, ZERO)
        result += gain*off/D(len(layout))*cosine/dist**2*(z/dist)**mu
    return result

def slope_upper(mu):
    with localcontext() as ctx:
        ctx.rounding = ROUND_CEILING
        if mu == 0:
            q = 10**40
            sqrt10_upper = D(isqrt(10*q*q)+1)/D(q)
            return 100*sqrt10_upper/27
        return D(250)/27

def decode(y1, y2, mu, r, M, zlo, zhi, eps):
    assert mu in (0, 1) and r == 1 and zlo == 1 and zhi == 3
    U = (3*y2-y1)/(2*M)
    V = (3*y1-y2)/(2*M)
    if U <= 0:
        return dict(status='uncertified', Uhat=U, Vhat=V)
    k = mu+3
    qhat = V/U
    qlo = (zlo/(zlo*zlo+r*r).sqrt())**k
    qhi = (zhi/(zhi*zhi+r*r).sqrt())**k
    clipped_q = min(max(qhat, qlo), qhi)
    v = root(clipped_q, k)
    estimate = r*v/(1-v*v).sqrt()
    bound = slope_upper(mu)*4*eps/(M*U)
    return dict(status='certified', Uhat=U, Vhat=V, qhat=qhat,
                clipped=clipped_q != qhat, estimated_depth=estimate, bound=bound)

def encode(value):
    if isinstance(value, D): return str(value)
    if isinstance(value, dict): return {k:encode(v) for k,v in value.items()}
    if isinstance(value, list): return [encode(v) for v in value]
    return value

def write_csv(path, rows):
    keys = list(dict.fromkeys(key for row in rows for key in row))
    with path.open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader()
        for row in rows: writer.writerow(encode(row))

def run(specpath, output):
    spec = json.loads(specpath.read_text())
    assert spec['decimal_precision'] == 80 and spec['root_iterations'] == 300
    assert spec['M'] == spec['r'] == '1' and spec['depth_band'] == ['1','3']
    assert spec['coaxial_coefficients'] == ['0.25','0.75']
    assert spec['offaxis_totals'] == ['0.75','0.25']
    assert spec['mu_values'] == [0,1]
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(specpath, output/'SPEC.json')
    shutil.copy2(__file__, output/'two_observation_controls.py')
    invsqrt2 = 1/D(2).sqrt()
    normals = {'front':(ZERO,ZERO,-ONE), 'tilt_x_45':(invsqrt2,ZERO,-invsqrt2),
               'tilt_y_45':(ZERO,invsqrt2,-invsqrt2)}
    layouts = {'equal_antipodal_pair':[(ONE,ZERO),(-ONE,ZERO)],
               'uniform_four_ring':[(ONE,ZERO),(ZERO,ONE),(-ONE,ZERO),(ZERO,-ONE)]}
    coefficients = [(D('.25'),D('.75')),(D('.75'),D('.25'))]
    exact, noisy = [], []
    target, tol = D(spec['target_depth_error']), D(spec['numeric_tolerance'])
    max_forward, max_clean, max_excess = ZERO, ZERO, ZERO
    for mu, layout_name, normal_name, gain_string, depth_string in product(
            spec['mu_values'], spec['layouts'], spec['normal_labels'],
            spec['gain_values'], spec['depth_values']):
        z, gain, n = D(depth_string), D(gain_string), normals[normal_name]
        layout = layouts[layout_name]
        intensities = [forward(z,n,gain,mu,m,off,layout) for m,off in coefficients]
        qtrue = (z/(z*z+1).sqrt())**(mu+3)
        formula = [gain*(-n[2])/z**2*(m+off*qtrue) for m,off in coefficients]
        discrepancy = max(abs(a-b) for a,b in zip(intensities,formula))
        max_forward = max(max_forward,discrepancy)
        decoded = decode(*intensities,mu,ONE,ONE,ONE,D(3),ZERO)
        err = abs(decoded['estimated_depth']-z)
        max_clean = max(max_clean,err)
        metadata = dict(mu=mu, layout=layout_name, normal=normal_name, gain=gain, true_depth=z)
        exact.append(dict(**metadata,I1=intensities[0],I2=intensities[1],**decoded,
                          depth_error=err,forward_formula_discrepancy=discrepancy))
        for epsilon, sign1, sign2 in product(spec['epsilon_values'],spec['noise_signs'],spec['noise_signs']):
            eps = D(epsilon)
            y1,y2 = intensities[0]+sign1*eps,intensities[1]+sign2*eps
            decoded = decode(y1,y2,mu,ONE,ONE,ONE,D(3),eps)
            row = dict(**metadata,epsilon=eps,sign1=sign1,sign2=sign2,y1=y1,y2=y2,**decoded)
            if decoded['status'] == 'certified':
                err = abs(decoded['estimated_depth']-z)
                excess = err-decoded['bound']
                max_excess = max(max_excess,excess)
                assert excess <= tol
                row.update(depth_error=err,target_met=err<=target,
                           target_certified=decoded['bound']<=target)
            noisy.append(row)
    sigma = 29*D(145).sqrt()/250-D(2)/5
    nu = 1/(1+sigma*sigma).sqrt()
    gamma2 = D(16)/25/nu
    n2 = (sigma*nu,ZERO,-nu)
    pair = layouts['equal_antipodal_pair']
    scene1 = [forward(D('.5'),normals['front'],ONE,0,m,off,pair) for m,off in coefficients]
    scene2 = [forward(D('.4'),n2,gamma2,0,m,off,pair) for m,off in coefficients]
    q0 = 1/(5*D(5).sqrt())
    reference = [1+3*q0,3+q0]
    gap = max(abs(x-y) for scene in [scene1,scene2] for x,y in zip(scene,reference))
    assert D('.4') < sigma < 1 and abs(sum(x*x for x in n2)-1) <= tol
    assert D('.4')-sigma < 0 and gap <= tol
    collision = dict(sigma=sigma,construction=spec['collision'],normal2=list(n2),gain2=gamma2,
                     scene1_intensities=scene1,scene2_intensities=scene2,reference=reference,gap=gap)
    assert len(exact)==spec['expected_clean_rows']==108 and len(noisy)==spec['expected_noisy_rows']==864
    assert max_clean<=tol and max_forward<=tol
    per_eps = {}
    for eps in spec['epsilon_values']:
        rows = [row for row in noisy if row['epsilon']==D(eps)]
        certified = [row for row in rows if row['status']=='certified']
        per_eps[eps] = dict(rows=len(rows),max_observed_error=max(r['depth_error'] for r in certified),
                            max_bound=max(r['bound'] for r in certified),
                            target_met_rows=sum(r['target_met'] for r in certified),
                            target_certified_rows=sum(r['target_certified'] for r in certified))
    summary = dict(status='PASS',spec_sha256=hashlib.sha256(specpath.read_bytes()).hexdigest(),
                   decimal_precision=80,clean_rows=len(exact),noisy_rows=len(noisy),
                   max_clean_depth_error=max_clean,max_forward_formula_discrepancy=max_forward,
                   max_bound_excess=max_excess,uncertified_rows=sum(r['status']!='certified' for r in noisy),
                   per_epsilon=per_eps,collision_gap=gap)
    write_csv(output/'EXACT_ROWS.csv',exact);write_csv(output/'NOISY_ROWS.csv',noisy)
    (output/'COLLISION.json').write_text(json.dumps(encode(collision),indent=2)+'\n')
    (output/'SUMMARY.json').write_text(json.dumps(encode(summary),indent=2)+'\n')
    print(json.dumps(encode(summary)))

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--spec',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    run(args.spec,args.output)
