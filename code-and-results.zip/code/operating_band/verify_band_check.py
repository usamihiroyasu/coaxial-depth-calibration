from fractions import Fraction as F
from math import isqrt
from decimal import Decimal,localcontext
from pathlib import Path
import json,argparse
W=Path(__file__).resolve().parent
q=10**40
rows=[]
for T in [0,1,8,64]:
    disc=9*T*T+8
    k=isqrt(disc*q*q)
    lo,hi=F(k,q),F(k+1,q)
    assert lo*lo<=disc<hi*hi
    tlo,thi=(3*T+lo)/4,(3*T+hi)/4
    poly=lambda t:1-2*t*t+3*T*t
    assert tlo>T and poly(tlo)>=0 and poly(thi)<0
    before,after=tlo-F(1,1000),thi+F(1,1000)
    assert before>T and poly(before)>0 and poly(after)<0
    rows.append({'T':T,'t_dec_lower':[str(tlo.numerator),str(tlo.denominator)],'t_dec_upper':[str(thi.numerator),str(thi.denominator)],'lit_at_lower_bound':True,'quadratic_root_enclosed':True,'slope_signs_checked_on_both_sides':True})
with localcontext() as ctx:
    ctx.prec=80
    value=(Decimal(3)+Decimal(17).sqrt())/4
    display=value.quantize(Decimal('.0001'))
    assert str(display)=='1.7808'
result={'status':'PASS','claim':'For isotropic sources with ri<=rmax and unit normals in the tilt cone, zmin>=rmax*t_dec(T) gives strict decrease on every positive-width finite band with m0=0.','analytic_proof':['Let d=sqrt(9T^2+8). Then 8*(1-2*t_dec^2+3T*t_dec)=8+9T^2-d^2=0.','t_dec>T for every T>=0; all sources are lit on the stated band.','For t>=t_dec, the numerator polynomial has derivative -4t+3T<=-d<0.','Since u>=-T, the derivative numerator 1-2t^2-3ut is at most 1-2t^2+3Tt.','At every interior depth z>zmin, this upper bound is strictly negative for every source. Positive coefficients and gain preserve strict decrease.'],'finite_checks_role':'Exact rational checks validate the printed root enclosure and signs; the continuum claim follows from the displayed algebra.','cases':rows,'T1_value':str(value),'T1_five_sigfig_display':str(display),'no_sharpness_or_inverse_stability_claim_for_this_band_check':True}
parser=argparse.ArgumentParser()
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
args.output.parent.mkdir(parents=True,exist_ok=True)
with args.output.open('x') as stream: stream.write(json.dumps(result,indent=2)+'\n')
print('BAND_CHECK_PASS')
