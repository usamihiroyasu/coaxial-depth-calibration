import math


def critical(T):
    if T < 0:
        raise ValueError("T must be non-negative")
    if T >= 1:
        return T**3 / (2 * (1 + T*T)**1.5)
    lo, hi = 0.0, 2.0
    for _ in range(100):
        mid = (lo + hi) / 2
        P_mid = 1 + 4*T*mid - 4*mid*mid - T*mid**3
        if P_mid > 0:
            lo = mid
        else:
            hi = mid
    t = (lo + hi) / 2
    return t**3 * (1 - 2*t*t + 3*T*t) / (2 * (1 + t*t)**2.5)


def normal(T):
    if T < 0:
        raise ValueError("T must be non-negative")
    d = math.sqrt(1 + T*T)
    return (-T/d, 0, -1/d)


def irradiance3d(z, n, lights):
    if z <= 0:
        raise ValueError("z must be positive")
    total = 0.0
    for x, y, m in lights:
        if m < 0:
            raise ValueError("light coefficient m must be non-negative")
        dx, dy, dz = x - 0.0, y - 0.0, 0.0 - z
        dist2 = dx*dx + dy*dy + dz*dz
        dist = math.sqrt(dist2)
        ux, uy, uz = dx/dist, dy/dist, dz/dist
        dot_val = n[0]*ux + n[1]*uy + n[2]*uz
        total += m * max(dot_val, 0.0) / dist2
    return total


def reduced(z, n, lights):
    if z <= 0:
        raise ValueError("z must be positive")
    nz = -n[2]
    total = 0.0
    for x, y, m in lights:
        if m < 0:
            raise ValueError("light coefficient m must be non-negative")
        r2 = x*x + y*y
        h = n[0]*x + n[1]*y
        numerator = max(nz*z + h, 0.0)
        denominator = (z*z + r2)**1.5
        total += m * numerator / denominator
    return total


def derivative(z, n, lights):
    if z <= 0:
        raise ValueError("z must be positive")
    nz = -n[2]
    total = 0.0
    for x, y, m in lights:
        if m < 0:
            raise ValueError("light coefficient m must be non-negative")
        r2 = x*x + y*y
        h = n[0]*x + n[1]*y
        val = nz*z + h
        if val > 0 or (val == 0 and nz > 0):
            total += m * (nz*(r2 - 2*z*z) - 3*h*z) / (z*z + r2)**2.5
    return total