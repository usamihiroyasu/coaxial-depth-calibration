"""Numerical checks for common-radius residual balance."""
from decimal import Decimal, localcontext
from pathlib import Path
import csv
import hashlib
import io
import json

D = Decimal

def maximizer(delta):
    lo, hi = D('0.5'), D(1)
    for _ in range(240):
        t = (lo + hi) / 2
        f = 1 + 4 * delta * t - 4 * t * t - delta * t**3
        if f > 0:
            lo = t
        else:
            hi = t
    return (lo + hi) / 2

def coefficient(delta):
    t = maximizer(delta)
    return t**3 * (1 - 2*t*t + 3*delta*t) / (2*(1+t*t)**D('2.5'))

def envelope(t, delta):
    return t**3 * (1 - 2*t*t + 3*delta*t) / (1+t*t)**D('2.5')

def direct(z, eps, rho, nu):
    result = nu*rho/z**2
    n = (nu, D(0), -nu)
    ay = (1-eps*eps).sqrt()
    for y in (ay, -ay):
        vector = (-eps, y, -z)
        distance2 = sum(v*v for v in vector)
        distance = distance2.sqrt()
        cosine = sum(a*b/distance for a,b in zip(n,vector))
        result += max(D(0), cosine) / (2*distance2)
    return result

def run(spec, original_threshold_csv):
    with localcontext() as ctx:
        ctx.prec = 80
        nu, h = 1 / D(2).sqrt(), D('1e-12')
        rows, c0 = [], coefficient(D(0))
        for text in spec['epsilon']:
            eps = D(text)
            tstar, c = maximizer(eps), coefficient(eps)
            z = tstar if eps < 1 else 1 + D(2)**-20
            for factor_text in spec['coefficient_factors']:
                factor, rho = D(factor_text), D(factor_text)*c
                value = direct(z, eps, rho, nu)
                reduced = nu*rho/z**2 + nu*max(D(0),z-eps)/(1+z*z)**D('1.5')
                slope = -2*rho + envelope(z, eps)
                fd = z**3 * (direct(z+h,eps,rho,nu)-direct(z-h,eps,rho,nu))/(2*h*nu)
                assert abs(value-reduced) < D('1e-75')
                assert abs(fd-slope) < D('1e-20')
                if factor < 1:
                    assert slope > 0
                elif factor > 1:
                    assert slope < 0
                elif eps < 1:
                    assert abs(slope) < D('1e-65')
                else:
                    assert slope < 0
                rows.append(dict(epsilon=str(eps),T='1',factor=str(factor),coefficient=str(c),ratio_to_balanced=str(c/c0),witness_depth=str(z),maximizer=str(tstar),irradiance_error=str(abs(value-reduced)),normalized_derivative=str(slope),fd_error=str(abs(fd-slope)),shadow_limit=bool(eps==1)))
        curve=[]
        for row in csv.DictReader(original_threshold_csv.splitlines()):
            # The plotting abscissae are retained from the existing figure.
            # tan(theta) is evaluated only for these fixed display coordinates.
            import math
            angle = row['angle_deg']
            tilt = D(str(math.tan(math.radians(float(angle)))))
            delta = D('0.1')*tilt
            assert delta <= 1
            curve.append(dict(angle_deg=angle,epsilon='0.1',tilt=str(tilt),delta=str(delta),coefficient=str(coefficient(delta))))
        return rows, curve

if __name__ == '__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--spec',required=True,type=Path)
    parser.add_argument('--threshold',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    spec_bytes=args.spec.read_bytes()
    spec=json.loads(spec_bytes)
    args.output.mkdir(parents=True,exist_ok=False)
    rows, curve=run(spec,args.threshold.read_text())
    (args.output/'ROWS.json').write_text(json.dumps(rows,indent=2)+'\n')
    stream=io.StringIO(); writer=csv.DictWriter(stream,fieldnames=list(curve[0]));writer.writeheader();writer.writerows(curve)
    (args.output/'tolerance.csv').write_text(stream.getvalue())
    summary=dict(rows=len(rows),curve_points=len(curve),precision=80,max_irradiance_error=max(D(x['irradiance_error'])for x in rows).__str__(),max_fd_error=max(D(x['fd_error'])for x in rows).__str__(),spec_sha256=hashlib.sha256(spec_bytes).hexdigest(),optical_measurements=0)
    (args.output/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))
