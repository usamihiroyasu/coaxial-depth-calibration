"""Frozen mismatch controls: direct LED angular emission times 3D Lambertian incidence."""
import math, json
from pathlib import Path

def intensity(z, mu, coax):
    total = 0.
    for x, m in [(2., .5), (-2., .5), (0., coax)]:
        distance = math.sqrt(x*x+z*z)
        emission_cosine = z/distance
        normal_incidence = z/distance
        total += m * emission_cosine**mu * normal_incidence / distance**2
    return total

def derivative(z, mu, coax):
    return -2*coax/z**3 + z**mu*((mu+1)*4-2*z*z)/(z*z+4)**((mu+5)/2)

c0 = 1/(25*math.sqrt(5))
rows = []
for mu, budget, sign in [(0., 1.2*c0, -1), (1., 1.2*c0, 1), (1., 1.2/27, -1)]:
    z=math.sqrt(2); step=1e-5*z
    fd=(intensity(z+step,mu,budget)-intensity(z-step,mu,budget))/(2*step)
    analytic=derivative(z,mu,budget)
    assert analytic*sign>0 and fd*sign>0
    assert abs(fd-analytic)<1e-8
    rows.append({'mu':mu,'coaxial_coefficient':budget,'depth':z,
                 'derivative':analytic,'physical_FD':fd,'expected_sign':sign})
out={'status':'PASS','rows':rows,'ideal_model_only':True,'captured_optical_data':False,
     'conclusion':'The isotropic guarantee is not an angular-LED guarantee; correcting the model changes the budget.'}
Path(__file__).with_name('RESULTS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
