"""Fixed-budget allocation and bounded calibration-error controls."""
import argparse,csv,hashlib,json,math
from decimal import Decimal as D,localcontext
from fractions import Fraction as F
from pathlib import Path

def sqrt_bounds(x,digits):
 q=10**digits;k=math.isqrt(x.numerator*q*q//x.denominator);lo=F(k,q)
 return lo,lo if lo*lo==x else F(k+1,q)

def critical_bounds(delta,steps,digits):
 a,b=F(1,2),F(1)
 if delta==0:b=a
 elif delta==1:a=b
 else:
  for _ in range(steps):
   t=(a+b)/2;v=1+4*delta*t-4*t*t-delta*t*t*t
   if v>0:a=t
   else:b=t
 nl=a**3*(1-2*b*b+3*delta*a);nh=b**3*(1-2*a*a+3*delta*b)
 assert nl>0
 dl=(1+a*a)**2*sqrt_bounds(1+a*a,digits)[0]
 dh=(1+b*b)**2*sqrt_bounds(1+b*b,digits)[1]
 return nl/(2*dh),nh/(2*dl)

def dec(x):return D(x.numerator)/D(x.denominator) if isinstance(x,F) else D(x)
def text(x):return str(dec(x)) if isinstance(x,F) else str(x)
def ceil_coefficient(x):
 q=10**40;return F(-((-x.numerator*q)//x.denominator),q)
def pack(x):return {'lower':text(x[0]),'upper':text(x[1]),'upper_exact':[str(x[1].numerator),str(x[1].denominator)]}
def write_csv(path,rows):
 with path.open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--spec',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 raw=args.spec.read_bytes();s=json.loads(raw);args.output.mkdir(parents=True,exist_ok=False);O=args.output
 with localcontext() as ctx:
  ctx.prec=s['decimal_precision'];M=F(s['budget_M']);gain=F(s['gain']);r=F(s['common_radius']);a,b=map(F,s['depth_band']);target=F(s['target_depth_error']);eps=F(s['measurement_error_cap'])
  assert M>0 and gain>0 and r>0 and 0<a<b and 0<target<b-a and eps>0
  nu=sqrt_bounds(F(1,2),s['fraction_sqrt_digits'])[0];nomnu=1/D(2).sqrt()
  bounds={name:critical_bounds(F(v['threshold_delta']),s['critical_root_bisections'],s['fraction_sqrt_digits']) for name,v in s['classes'].items()};cs={name:v[1] for name,v in bounds.items()}
  eta_req=b**3*eps/(2*gain*nu*target);assert eta_req<M
  base={name:ceil_coefficient((c*M+eta_req)/(1+c)) for name,c in cs.items()}
  zs=b-target;u=1/zs**2;v=1/(zs**2+r*r);H=u-1/b**2;K=1/(nu*H)
  beta_limit=(nu*M*H-eps/gain)/(M*u)
  def robust(c,beta):
   denominator=1+c-K*beta*(u-v)
   if denominator<=0:return None,'nonpositive_denominator'
   m=ceil_coefficient((c*M+K*(eps/gain+beta*M*v))/denominator)
   if not 0<m<M:return None,'budget_limit'
   margin=m-c*(M-m);assert margin>0
   assert eps/gain+beta*(m*u+(M-m)*v)<=nu*margin*H
   return m,'certified'
  def bound_for(m,c,beta):
   margin=m-c*(M-m);assert margin>0
   def ok(t):
    z=b-t;return eps/gain+beta*(m/z**2+(M-m)/(z**2+r*r))<=nu*margin*(1/z**2-1/b**2)
   if not ok(b-a):return b-a,False
   lo,hi=F(0),b-a
   for _ in range(120):
    mid=(lo+hi)/2
    if ok(mid):hi=mid
    else:lo=mid
   assert ok(hi)
   return hi,True
  budget=[]
  for j in range(s['budget_curve_points']):
   z=F(j,s['budget_curve_points']-1);budget.append(dict(u=text(z),**{name:text((c+z)/(1+c)) for name,c in cs.items()}))
  mismatch=[]
  for j in range(s['mismatch_curve_points']):
   beta=F(s['mismatch_curve_beta_max'])*j/(s['mismatch_curve_points']-1);row={'beta':text(beta)}
   for name,c in cs.items():
    m,_=robust(c,beta);row[name]='nan' if m is None else text(m/M)
   mismatch.append(row)
  nominal=( -nomnu,D(0),-nomnu );tangents=[(nomnu,D(0),-nomnu),(D(0),D(1),D(0))]
  allrows=[];cells=[];forward_max=D(0);mismatch_violation=D(0);roundtol=D('1e-55')
  for name,c in cs.items():
   for rn_text in s['normal_difference_caps']:
    for rg_text in s['relative_gain_caps']:
     rn,rg=F(rn_text),F(rg_text);assert 0<=rn<F(1,10) and 0<=rg<1;beta=rn+rg;mr,status=robust(c,beta)
     cell={'class':name,'rho_n':str(rn),'rho_gain':str(rg),'beta':text(beta),'robust_status':status,'nominal_m0':text(base[name]),'robust_m0':None if mr is None else text(mr),'strategies':{}}
     for scheme,m in [('nominal_uniform',base[name])]+([] if mr is None else [('pointwise_robust',mr)]):
      S=M-m;md,sd,rd=map(dec,[m,S,r]);margin=m-c*S
      if name=='unrestricted':off=[(rd,D(0),sd)]
      else:
       x=rd*(D('0.1') if name=='residual' else D(0));y=(rd*rd-x*x).sqrt();off=[(x,y,sd/2),(x,-y,sd/2)]
      lights=[(D(0),D(0),md)]+off
      def nominal_response(z):
       x=off[0][0];return dec(gain)*(nomnu*md/(z*z)+sd*max(nomnu*(z-x),D(0))/((z*z+rd*rd)*(z*z+rd*rd).sqrt()))
      def reduced_response(z,n,g):return g*sum((strength*max(-n[2]*z+n[0]*x+n[1]*y,D(0))/((z*z+x*x+y*y)*(z*z+x*x+y*y).sqrt()) for x,y,strength in lights),D(0))
      def direct_response(z,n,g):
       total=D(0)
       for x,y,strength in lights:
        d2=x*x+y*y+z*z;dist=d2.sqrt();cosine=n[0]*(x/dist)+n[1]*(y/dist)+n[2]*(-z/dist);total+=strength*max(cosine,D(0))/d2
       return g*total
      ilo,ihi=nominal_response(dec(b)),nominal_response(dec(a))
      def invert(observed):
       yy=min(max(observed,ilo),ihi);lo,hi=dec(a),dec(b)
       for _ in range(s['bisection_steps']):
        mid=(lo+hi)/2
        if nominal_response(mid)>yy:lo=mid
        else:hi=mid
       return (lo+hi)/2,yy!=observed
      analytic_bound,nontrivial=bound_for(m,c,beta)
      if scheme=='pointwise_robust':analytic_bound=min(analytic_bound,target)
      global_bound=b**3*(eps+gain*beta*(m/a**2+S/(a*a+r*r)))/(2*gain*nu*margin);rows=[]
      rr=dec(rn);co=1-rr*rr/2;si=rr*(1-rr*rr/4).sqrt()
      for tangent_id,tangent in enumerate(tangents):
       for ns in s['normal_perturbation_signs']:
        true_n=tuple(co*n+ns*si*t for n,t in zip(nominal,tangent));assert -true_n[2]>0
        assert abs(sum(x*x for x in true_n)-1)<D('1e-75')
        assert sum((x-y)**2 for x,y in zip(true_n,nominal)).sqrt()<=rr+D('1e-75')
        for gs in s['gain_signs']:
         true_gain=dec(gain)*(1+gs*dec(rg));assert true_gain>0
         for zz in s['depths']:
          z=D(zz);truth=direct_response(z,true_n,true_gain);red=reduced_response(z,true_n,true_gain);forward_max=max(forward_max,abs(truth-red));assert abs(truth-red)<D('1e-70')
          nominal_i=nominal_response(z);model_cap=dec(gain*beta)*(md/(z*z)+sd/(z*z+rd*rd));gap=abs(truth-nominal_i)-model_cap;mismatch_violation=max(mismatch_violation,gap);assert gap<roundtol
          for noise_sign in s['noise_signs']:
           noisy=truth+noise_sign*dec(eps);recovered,clipped=invert(noisy);error=abs(recovered-z);assert error<=dec(analytic_bound)+roundtol
           if scheme=='pointwise_robust':assert error<=dec(target)+roundtol
           row={'class':name,'rho_n':text(rn),'rho_gain':text(rg),'scheme':scheme,'m0':text(m),'offaxis_S':text(S),'tangent':tangent_id,'normal_sign':ns,'gain_sign':gs,'true_depth':str(z),'noise_sign':noise_sign,'true_intensity':str(truth),'nominal_intensity':str(nominal_i),'model_error':str(abs(truth-nominal_i)),'pointwise_model_cap':str(model_cap),'estimated_depth':str(recovered),'depth_error':str(error),'target_met':error<=dec(target)+roundtol,'endpoint_clipped':clipped};rows.append(row);allrows.append(row)
      cell['strategies'][scheme]={'m0':text(m),'m0_exact':[str(m.numerator),str(m.denominator)],'margin_lower':text(margin),'global_error_bound':text(global_bound),'pointwise_depth_bound':text(analytic_bound),'pointwise_bound_nontrivial':nontrivial,'rows':len(rows),'max_observed_depth_error':max(D(x['depth_error']) for x in rows).__str__(),'target_met':sum(x['target_met'] for x in rows)}
     cells.append(cell)
  assert len(cells)==36 and len(budget)==51 and len(mismatch)==61
  summary={'status':'PASS','spec_sha256':hashlib.sha256(raw).hexdigest(),'decimal_precision':s['decimal_precision'],'certificate_arithmetic':'exact rational; upper threshold, lower normal component, upward-rounded coefficients','classes':{name:{'threshold_enclosure':pack(bounds[name]),'nominal_fixed_budget_m0':text(base[name])}for name in cs},'nu_lower_exact':[str(nu.numerator),str(nu.denominator)],'nominal_eta_required':text(eta_req),'combined_cap_limit':text(beta_limit),'cells':len(cells),'certified_robust_cells':sum(x['robust_status']=='certified' for x in cells),'uncertified_cells':sum(x['robust_status']!='certified' for x in cells),'rows':len(allrows),'nominal_design_max_error':max(D(x['depth_error']) for x in allrows if x['scheme']=='nominal_uniform').__str__(),'nominal_design_target_failures':sum(not x['target_met'] for x in allrows if x['scheme']=='nominal_uniform'),'robust_design_max_error':max(D(x['depth_error']) for x in allrows if x['scheme']=='pointwise_robust').__str__(),'robust_design_target_failures':sum(not x['target_met'] for x in allrows if x['scheme']=='pointwise_robust'),'max_independent_forward_difference':str(forward_max),'max_pointwise_model_bound_roundoff_violation':str(mismatch_violation),'budget_curve_points':len(budget),'mismatch_curve_points':len(mismatch),'true_response_monotonicity_assumed':False,'optical_measurements':0,'model_training_runs':0,'all_predefined_cells_retained':True}
  for filename,data in [('SUMMARY.json',summary),('CELLS.json',cells)]: (O/filename).write_text(json.dumps(data,indent=2)+'\n')
  write_csv(O/'ROWS.csv',allrows);write_csv(O/'budget_curve.csv',budget);write_csv(O/'mismatch_curve.csv',mismatch);(O/'SPEC.json').write_bytes(raw);(O/'design_controls.py').write_bytes(Path(__file__).read_bytes())
  print(json.dumps(summary))
if __name__=='__main__':main()
