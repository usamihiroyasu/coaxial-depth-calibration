"""Summarize paired controls from the stored fixed-budget study."""
from pathlib import Path
from decimal import Decimal
import csv, json, hashlib, argparse

def summarize(path):
    rows=list(csv.DictReader(path.open()))
    fields=['class','rho_n','rho_gain','tangent','normal_sign','gain_sign','true_depth','noise_sign']
    key=lambda row:tuple(row[name] for name in fields)
    nominal=[row for row in rows if row['scheme']=='nominal_uniform']
    robust=[row for row in rows if row['scheme']=='pointwise_robust']
    nom_by_key={key(row):row for row in nominal}
    robust_by_key={key(row):row for row in robust}
    assert len(nom_by_key)==len(nominal) and len(robust_by_key)==len(robust)
    assert set(robust_by_key)<=set(nom_by_key)
    paired=[nom_by_key[k] for k in robust_by_key]
    target=Decimal('0.02')
    stats=lambda data:{'controls':len(data),'maximum_depth_error':str(max(Decimal(r['depth_error']) for r in data)),'target_exceedances':sum(Decimal(r['depth_error'])>target for r in data)}
    return {'source_ROWS_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'matching_fields':fields,'target_depth_error':str(target),'matched_nominal':stats(paired),'matched_robust':stats(robust),'all_nominal':stats(nominal),'selection':'Settings with an analytic robust allocation; paired before comparing observed errors'}

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--rows',type=Path,default=Path(__file__).with_name('ROWS.csv'))
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    result=summarize(args.rows)
    with args.output.open('x') as stream: json.dump(result,stream,indent=2); stream.write('\n')
    print('MATCHED_COMPARISON_PASS')
