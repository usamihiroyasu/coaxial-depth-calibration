"""Ideal-radiometry controls for calibrated near-field depth inversion."""
import csv, json, math
from pathlib import Path
from decimal import Decimal as D, localcontext
from radiometry import critical, normal, irradiance3d, reduced, derivative

P = Path(__file__).resolve().parent
def save_csv(name, columns, rows):
    with (P / name).open('w', newline='') as f:
        w = csv.writer(f); w.writerow(columns); w.writerows(rows)
def root_t(T):
    lo, hi = 0., 2.
    for _ in range(100):
        t = (lo+hi)/2
        if 1+4*T*t-4*t*t-T*t**3 > 0: lo=t
        else: hi=t
    return (lo+hi)/2

assert abs(irradiance3d(2, normal(0), [(0,0,1)])-.25)<1e-15
assert abs(irradiance3d(4, normal(0), [(3,0,1)])-4/125)<1e-15
assert irradiance3d(1,normal(1),[(1,0,1)]) == 0
assert abs(derivative(1,normal(1),[(1,0,1)])-.25)<1e-15
for fn, args in [(critical,(-1,)),(normal,(-1,)),(irradiance3d,(0,normal(0),[])),(reduced,(1,normal(0),[(0,0,-1)]))]:
    try: fn(*args)
    except ValueError: pass
    else: raise AssertionError('input rejection failed')
n=normal(.5); lights=[(2,0,1),(0,1,.5),(0,0,.2)]
rot_n=(-n[1],n[0],n[2]); rot_lights=[(-y,x,m) for x,y,m in lights]
assert abs(irradiance3d(1.25,n,lights)-irradiance3d(1.25,rot_n,rot_lights))<1e-15
layouts=[[(2,0,1)],[(2,0,.5),(-2,0,.5)],[(1,0,.2),(0,1.5,.3),(-2,0,.5)]]
rows=[]; fd_modes={'central':0,'right_second_order':0}; maxval=maxfd=maxgap=0.
for T in [0,.5,1,2]:
    n=normal(T); c=critical(T)
    for j,off in enumerate(layouts):
        lamps=off+[(0,0,1.2*c)]
        for z in [.5,.75,1.25,2.5,5]:
            value=irradiance3d(z,n,lamps); a=derivative(z,n,lamps); h=1e-5*z
            kink=any(abs(-n[2]*z+n[0]*x+n[1]*y)<1e-14 for x,y,m in off)
            mode='right_second_order' if kink else 'central';fd_modes[mode]+=1
            if kink: fd=(-3*value+4*irradiance3d(z+h,n,lamps)-irradiance3d(z+2*h,n,lamps))/(2*h)
            else: fd=(irradiance3d(z+h,n,lamps)-irradiance3d(z-h,n,lamps))/(2*h)
            e=abs(value-reduced(z,n,lamps)); ef=abs(fd-a); gap=a*z**3/(-n[2])+2*.2*c
            assert e<=1e-12 and ef<=1e-6 and gap<=1e-12,(T,j,z,e,ef,gap)
            maxval=max(maxval,e); maxfd=max(maxfd,ef);maxgap=max(maxgap,gap)
            rows.append([T,j,z,e,ef,gap,mode])
save_csv('physical_controls.csv',['T','layout','depth','radiometry_error','FD_error','gap_residual','FD_mode'],rows)
sharp=[]
for T in [0,.5,1,2]:
    t=root_t(T) if T<1 else T+2**-12;z=2*t
    for factor in [.8,1,1.2]:
        v=derivative(z,normal(T),[(2,0,1),(0,0,factor*critical(T))])
        assert (v>0 if factor<1 else v<=1e-12 if factor==1 else v<0)
        sharp.append({'T':T,'factor':factor,'depth':z,'derivative':v})
save_csv('threshold.csv',['angle_deg','T','critical'],[(a,math.tan(math.radians(a)),critical(math.tan(math.radians(a)))) for a in range(0,81,5)])
save_csv('response.csv',['depth','below','critical','above'],[[z]+[z**3*derivative(z,normal(0),[(2,0,1),(0,0,f*critical(0))]) for f in [.8,1,1.2]] for z in [.4+.004*i for i in range(401)]])
noise=[];slopes={}
with localcontext() as ctx:
    ctx.prec=80;c=D(1)/(D(25)*D(5).sqrt())
    for factor in [D('1'),D('1.2')]:
        m0=factor*c
        def intensity(z):
            distance=(D(4)+z*z).sqrt()
            return m0/(z*z)+(z/distance)/(distance*distance)
        center=intensity(D(1))
        for sign in [-1,1]:
            errs=[]
            for magnitude in ['1e-4','1e-6','1e-8','1e-10','1e-12']:
                eps=D(magnitude);target=center+D(sign)*eps;lo,hi=D('.5'),D('1.5')
                assert intensity(lo)>target>intensity(hi)
                for _ in range(240):
                    mid=(lo+hi)/2
                    if intensity(mid)>target:lo=mid
                    else:hi=mid
                error=abs((lo+hi)/2-D(1));bound=None
                if factor>1:
                    bound=D('1.5')**3/(2*(m0-c))*eps
                    assert error<=bound+D('1e-65')
                errs.append(error);noise.append([str(factor),sign,str(eps),str(error),str(bound) if bound else ''])
            slopes[f'{factor}:{sign}']=math.log(float(errs[-1]/errs[0]))/math.log(1e-8)
save_csv('noise.csv',['factor','sign','noise','error','bound'],noise)
result={'status':'PASS','hand_controls':9,'physical_cases':len(rows),'FD_modes':fd_modes,'max_3D_reduced_error':maxval,'max_FD_error':maxfd,'max_positive_gap_violation':maxgap,'sharpness_cases':sharp,'noise_cases':len(noise),'noise_rows':noise,'endpoint_log_slopes':slopes,'model_or_optical_data':False,'note':'Numerical ideal-model controls; continuum theorem and scientific priority are separate.'}
(P/'RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['sharpness_cases','noise_rows']}))
