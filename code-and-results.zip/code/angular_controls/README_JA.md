# Aligned angular-emission controls

The controls evaluate emission exponent 1 and tilt-slope bounds 0, 1, 8, and 64. Three coefficient factors and three orientations give 36 cases.

Copy `angular_controls.py` and `EFFECTIVE_SPEC.json` into a fresh directory and run `python3 angular_controls.py`. Results contain the candidate roots, branch membership, physical comparisons, and finite-difference checks. Root counts use exact rational arithmetic; coefficient values use 80-digit Decimal arithmetic. A shadow-boundary supremum is paired with a strictly lit approaching configuration.
