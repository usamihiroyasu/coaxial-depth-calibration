"""One frozen mu=1 angular-envelope validation; exact root counts, numerical kappa."""
from pathlib import Path
from fractions import Fraction as F
from decimal import Decimal as D, getcontext
import json, hashlib, datetime, traceback

ROOT = Path(__file__).resolve().parent
getcontext().prec = 80
WIDTH = F(1, 2**220)

def trim(p):
    p = list(p)
    while len(p)>1 and p[-1]==0: p.pop()
    return p

def value(p,x):
    z=F(0)
    for c in reversed(p): z=z*x+c
    return z

def derivative(p):
    return trim([F(i)*p[i] for i in range(1,len(p))] or [F(0)])

def divide(a,b):
    a=trim(a); b=trim(b)
    if b==[0]: raise ZeroDivisionError()
    q=[F(0)]*max(1,len(a)-len(b)+1)
    while a!=[0] and len(a)>=len(b):
        j=len(a)-len(b); c=a[-1]/b[-1]; q[j]+=c
        for i,bi in enumerate(b): a[i+j]-=c*bi
        a=trim(a)
    return trim(q),a

def squarefree(p):
    a,b=trim(p),derivative(p)
    while b!=[0]: a,b=b,divide(a,b)[1]
    gcd=[c/a[-1] for c in a]
    q,r=divide(p,gcd); assert r==[0]
    return trim(q)

def sequence(p):
    out=[p,derivative(p)]
    while out[-1]!=[0]:
        r=divide(out[-2],out[-1])[1]
        if r==[0]: break
        out.append([-c for c in r])
    return out

def variations(seq,x):
    s=[1 if v>0 else -1 for p in seq if (v:=value(p,x))!=0]
    return sum(a!=b for a,b in zip(s,s[1:]))

def isolate(p):
    p=trim(p)
    while len(p)>1 and p[0]==0: p=p[1:]
    p=squarefree(p)
    if len(p)<=1:return [],{'distinct_positive_count':0}
    seq=sequence(p)
    bound=F(1)+max(abs(c/p[-1]) for c in p[:-1]); B=F(1)
    while B<=bound:B*=2
    count=variations(seq,F(0))-variations(seq,B)
    todo=[(F(0),B,count)]; roots=[]; split_count=0
    while todo:
        lo,hi,n=todo.pop()
        if n==0:continue
        if n==1 and hi-lo<=WIDTH:
            roots.append((lo,hi));continue
        mid=(lo+hi)/2
        if value(p,mid)==0:
            q,r=divide(p,[-mid,F(1)]);assert r==[0]
            rr,meta=isolate(q);rr.append((mid,mid));rr.sort(key=lambda x:sum(x)/2)
            assert len(rr)==count
            return rr,{'distinct_positive_count':count,'cauchy_upper':str(B),'rational_root_factor':str(mid),'subproblem':meta}
        left=variations(seq,lo)-variations(seq,mid)
        assert 0<=left<=n
        todo.append((mid,hi,n-left));todo.append((lo,mid,left));split_count+=1
    roots.sort(key=lambda x:sum(x)/2);assert len(roots)==count
    return roots,{'distinct_positive_count':count,'cauchy_upper':str(B),'dyadic_splits':split_count,'max_bracket_width':str(max((hi-lo for lo,hi in roots),default=F(0)))}

def dec(f):
    return D(f.numerator)/D(f.denominator) if isinstance(f,F) else D(f)

def g(t,u):
    return t**3*(t*(2-2*t*t)+u*(1-3*t*t))/(1+t*t)**3

def poly(u):return [3*u,F(8),-18*u,F(-16),3*u]

def compare_s(bracket):
    lo,hi=bracket
    if hi*hi<F(1,3):return -1
    if lo*lo>F(1,3):return 1
    raise AssertionError('Root interval straddles s: HOLD')

def compare_T(bracket,T):
    lo,hi=bracket
    if hi<T:return -1
    if lo>=T:return 1
    raise AssertionError('Root interval straddles T: HOLD')

def envelope(T):
    td=D(T); s=(D(1)/3).sqrt(); candidates=[]; root_evidence=[]
    def add(branch,label,t,u,v,shadow=False):
        candidates.append({'branch':branch,'kind':label,'t':t,'u':u,'value':v,'shadow_limit':shadow})
    add('positive_u','zero_limit',D(0),td,D(0))
    add('positive_u','s_endpoint',s,td,g(s,td))
    for branch,u in [('positive_u',F(T)),('negative_u',F(-T))]:
        roots,meta=isolate(poly(u)); evidence={'branch':branch,'u':str(u),'polynomial':[str(c) for c in poly(u)],'completeness':meta,'roots':[]}
        for bracket in roots:
            t=dec(sum(bracket)/2);res=abs(g_poly(poly(u),t))
            assert res<=D('1e-55')
            admitted=compare_s(bracket)<=0 if branch=='positive_u' else compare_s(bracket)>=0 and compare_T(bracket,F(T))>=0
            evidence['roots'].append({'lo':str(bracket[0]),'hi':str(bracket[1]),'mid':str(t),'polynomial_residual':str(res),'admitted':admitted})
            if admitted:add(branch,'quartic_root',t,dec(u),g(t,dec(u)))
        root_evidence.append(evidence)
    if td>=s:add('shadow','boundary_supremum',td,-td,(td*td/(1+td*td))**2,True)
    L=max(s,td);limit_value=(td*td/(1+td*td))**2 if L==td else g(L,-td)
    add('negative_u','lower_endpoint',L,-td,limit_value,L==td)
    add('negative_u','infinity_limit',None,-td,D(-2))
    order={'positive_u':0,'shadow':1,'negative_u':2}
    winner=min(candidates,key=lambda c:(-c['value'],order[c['branch']],c['t'] if c['t'] is not None else D('Infinity')))
    assert winner['value']>0 and winner['t'] is not None
    kappa=winner['value']/2;t=winner['t'];u=winner['u']
    if winner['shadow_limit']:u=-td+D(1)/(D(2)**20)
    nu=1/(1+td*td).sqrt();b=(td*nu,D(0))
    if T==0:a=(D(1),D(0))
    else:
        ax=u/td;a=(ax,max(D(0),1-ax*ax).sqrt())
    assert t+u>0
    return {'T':T,'kappa':kappa,'winner':winner,'physical_witness':{'t':t,'u':u,'a':a,'b':b,'nu':nu},'candidates':candidates,'root_evidence':root_evidence}

def g_poly(p,t):
    v=D(0)
    for c in reversed(p):v=v*t+dec(c)
    return v

def direct(z,a,b,nu,m0):
    total=D(0)
    for (ax,ay),m in [(a,D(1)),((D(0),D(0)),m0)]:
        distance=(ax*ax+ay*ay+z*z).sqrt()
        incidence=(b[0]*ax+b[1]*ay+nu*z)/distance
        emission=z/distance
        total+=m*emission*max(D(0),incidence)/(distance*distance)
    return total

def reduced(z,a,b,nu,m0):
    r2=a[0]*a[0]+a[1]*a[1];h=b[0]*a[0]+b[1]*a[1]
    return nu*m0/z**2+z*max(D(0),nu*z+h)/(z*z+r2)**2

def reduced_derivative(z,a,b,nu,m0):
    r2=a[0]*a[0]+a[1]*a[1];h=b[0]*a[0]+b[1]*a[1]
    off=D(0) if nu*z+h<=0 else (nu*z*(2*r2-2*z*z)+h*(r2-3*z*z))/(z*z+r2)**3
    return -2*nu*m0/z**3+off

def rotate(v):return (-v[1],v[0])

def serial(x):
    if isinstance(x,D):return str(x)
    if isinstance(x,dict):return {k:serial(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [serial(v) for v in x]
    return x

def main():
    spec=json.loads((ROOT/'EFFECTIVE_SPEC.json').read_text())
    attempted=ROOT/'SCIENTIFIC_ATTEMPTED.json'
    with attempted.open('x') as f:json.dump({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'effective_spec_sha256':hashlib.sha256((ROOT/'EFFECTIVE_SPEC.json').read_bytes()).hexdigest(),'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'max_runs':1},f,indent=2)
    try:
        envelopes=[];rows=[];checks=0
        for T in spec['T_values']:
            e=envelope(T);envelopes.append(e);w=e['physical_witness'];z=w['t'];nu=w['nu'];a=w['a'];b=w['b']
            for factor in [D('0.8'),D(1),D('1.2')]:
                m0=factor*e['kappa'];base_derivative=None
                for orientation,aa,bb in [('base',a,b),('joint_rot90',rotate(a),rotate(b)),('normal_rot90_only',a,rotate(b))]:
                    step=(D(2)**-26)*min(D(1),z)
                    margins=[nu*zz+bb[0]*aa[0]+bb[1]*aa[1] for zz in [z-step,z,z+step]]
                    assert all(v>0 for v in margins) or all(v<0 for v in margins),'FD crosses clamp: HOLD'
                    pd=direct(z,aa,bb,nu,m0);pr=reduced(z,aa,bb,nu,m0)
                    intensity_error=abs(pd-pr);assert intensity_error<=D('1e-65');checks+=1
                    derivative=reduced_derivative(z,aa,bb,nu,m0)
                    fd=(direct(z+step,aa,bb,nu,m0)-direct(z-step,aa,bb,nu,m0))/(2*step)
                    scale=z**3/nu;norm=derivative*scale;fd_error=abs((fd-derivative)*scale)
                    assert fd_error<=D('1e-9');checks+=1
                    if orientation=='base':base_derivative=norm
                    if orientation=='joint_rot90':assert abs(norm-base_derivative)<=D('1e-65');checks+=1
                    if factor>=1:assert norm<=D('1e-55');checks+=1
                    if orientation!='normal_rot90_only' and factor==D('0.8'):assert norm>0;checks+=1
                    if orientation!='normal_rot90_only' and factor==D('1.2'):assert norm<0;checks+=1
                    rows.append({'T':T,'factor':factor,'orientation':orientation,'z':z,'u_actual':(bb[0]*aa[0]+bb[1]*aa[1])/nu,'m0':m0,'intensity':pd,'intensity_error':intensity_error,'normalized_derivative':norm,'normalized_FD':fd*scale,'normalized_FD_error':fd_error,'FD_step':step,'min_lit_margin':min(margins)})
        out={'status':'PASS','effective_spec_sha256':hashlib.sha256((ROOT/'EFFECTIVE_SPEC.json').read_bytes()).hexdigest(),'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'rows':rows,'envelopes':envelopes,'row_count':len(rows),'numeric_assertions':checks,'max_intensity_error':max(x['intensity_error'] for x in rows),'max_normalized_FD_error':max(x['normalized_FD_error'] for x in rows),'root_counts_exact':True,'kappa_interval_certified':False,'captured_optical_data':False,'model_GPU_runs':0}
        (ROOT/'RESULTS.json').write_text(json.dumps(serial(out),ensure_ascii=False,indent=2)+'\n')
        print(json.dumps(serial({'status':'PASS','rows':len(rows),'assertions':checks,'max_FD_error':out['max_normalized_FD_error'],'winners':[{'T':e['T'],'branch':e['winner']['branch'],'kind':e['winner']['kind'],'kappa':e['kappa'],'root_counts':[x['completeness']['distinct_positive_count'] for x in e['root_evidence']]} for e in envelopes]}),indent=2))
    except Exception:
        (ROOT/'FAILURE.json').write_text(json.dumps({'status':'FAIL_NO_RETRY','traceback':traceback.format_exc(),'effective_spec_sha256':hashlib.sha256((ROOT/'EFFECTIVE_SPEC.json').read_bytes()).hexdigest()},indent=2)+'\n')
        raise

if __name__=='__main__':main()
