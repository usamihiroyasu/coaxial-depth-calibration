# Online Resource 1
Illumination Balance and Sharp Thresholds for Near-Field Depth Calibration

Hiroyasu Usami, Ayato Tsuboi, and Keisuke Hara

This archive contains the inputs, implementations, reference results, figure sources, and animation renderer needed to reproduce the paper's numerical calculations. The calculations use the radiometric models in the paper.

## Contents

| Path | Purpose and reference output |
|---|---|
| `code/radiometry.py`, `run_validation.py` | Direct 3D and reduced isotropic response; 60 radiometric/derivative cases, 12 extremal cases, and 20 inversion observations in `RESULTS.json`, `physical_controls.csv`, `noise.csv` |
| `code/balanced_controls.py` | 40 balanced pair/ring controls in `BALANCED_RESULTS.json` |
| `code/residual_balance/` | Imperfect-balance specification, 21 rows, and 17 tolerance-curve points in `ROWS.json`, `SUMMARY.json`, `tolerance.csv` |
| `code/angular_controls/` | Exponent-one branch enumeration and 36 orientation/coefficient controls in `RESULTS.json`; `rows.csv` is a reference summary |
| `code/prior_scope_controls/` | Three model-mismatch controls, including failure of an isotropic coefficient under angular emission, in `RESULTS.json` |
| `code/design_case/` | Twenty-observation coefficient-selection example in `ROWS.json` and `SUMMARY.json`; input/output specification included |
| `code/figure_sources/` | Standalone LaTeX sources and CSV inputs for Figures 1–3 |
| `code/animation/` | macOS renderer, formula cards, geometry/formula checks, and reproduction script |
| `docs/` | Angular enumeration procedure (PDF/LaTeX), implementation note, and historical input-lineage record |

## Numerical reproduction

Python 3 and its standard library suffice. From the archive root, create a fresh working copy to preserve the bundled references, then run:

```sh
mkdir reproduced
cp -R code reproduced/code
python3 reproduced/code/run_validation.py
python3 reproduced/code/balanced_controls.py
python3 reproduced/code/prior_scope_controls/anisotropy_controls.py
python3 reproduced/code/angular_controls/angular_controls.py
python3 reproduced/code/residual_balance/residual_controls.py --spec code/residual_balance/SPEC.json --threshold code/threshold.csv --output reproduced/residual
python3 reproduced/code/design_case/design_case.py --output-dir reproduced/design
```

Expected reports are `PASS`, `BALANCED40_PASS`, `PASS`, and `PASS` for the first four commands. The angular report has 36 rows and 124 numerical assertions; exact rational root counts accompany numerical coefficient values (`kappa_interval_certified` is false). Its attempt marker permits one run per fresh working copy. Residual reproduction reports 21 rows, 17 curve points, maximum irradiance error `3E-80`, and maximum derivative discrepancy about `4.51E-25`. Compare `reproduced/residual/{ROWS.json,tolerance.csv,SUMMARY.json}` with `code/residual_balance/`. The design summary reports 20 rows, inverse constant 200, depth tolerance 0.02, and target satisfaction of 6/10 (threshold) versus 10/10 (margin); compare with `code/design_case/`. Output directories for these two CLIs must be new.

The isotropic report retains maximum 3D/reduced discrepancy about `1.11E-16`, maximum derivative discrepancy about `6.26E-10`, and both perturbation signs at all five magnitudes. The angular reference retains maximum irradiance discrepancy `2E-80` and derivative discrepancy about `7.50E-16`. Floating-point summaries should be compared numerically with the stated tolerances, rather than by file hash. The protocols and specifications list the conditions used in each calculation.

## Figures and animation

Compile each `figure1.tex`, `figure2.tex`, and `figure3.tex` with `pdflatex -halt-on-error` from `code/figure_sources/` in the fresh copy. Required LaTeX packages include standalone, TikZ, and PGFplots. The adjacent CSV files are the plotted inputs.

On macOS, run `zsh reproduce.sh` from `reproduced/code/animation/` with Swift, LaTeX, and FFmpeg installed. The script prints a new temporary directory containing `lighting_thresholds_3d.gif` and `lighting_thresholds_3d_silent.mp4`; its final checks report `FORMULA_CHECKS_PASSED` and `PASSED`. The animation illustrates the flat-normal model at 0.8, 1, and 1.2 times the threshold.

