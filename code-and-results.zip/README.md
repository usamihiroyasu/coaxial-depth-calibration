# Online Resource 1
Illumination Balance and Sharp Thresholds for Near-Field Depth Calibration

Hiroyasu Usami, Ayato Tsuboi, and Keisuke Hara

This archive contains the inputs, implementations, reference results, figure sources, and animation renderer needed to reproduce the paper's numerical calculations. 
## Contents

| Path | Purpose and reference output |
|---|---|
| `code/radiometry.py`, `run_validation.py` | Direct 3D and reduced isotropic response; 60 radiometric/derivative cases, 12 extremal cases, and 20 inversion observations in `RESULTS.json`, `physical_controls.csv`, `noise.csv` |
| `code/balanced_controls.py` | 40 balanced pair/ring controls in `BALANCED_RESULTS.json` |
| `code/residual_balance/` | Imperfect-balance specification, 21 rows, and 17 tolerance-curve points in `ROWS.json`, `SUMMARY.json`, `tolerance.csv` |
| `code/angular_controls/` | Exponent-one branch enumeration and 36 orientation/coefficient controls in `RESULTS.json`; `rows.csv` is a reference summary |
| `code/prior_scope_controls/` | Three model-mismatch controls, including failure of an isotropic coefficient under angular emission, in `RESULTS.json` |
| `code/operating_band/` | Exact rational checks for the isotropic operating-band criterion; analytical derivation in `docs/OPERATING_BAND_CHECK.md` |
| `code/budget_robustness/` | Fixed-budget allocations, exact rational calibration-error certificates, 36 class--cap settings and all 3,456 controls |
| `code/two_observation/` | Two-allocation inversion without normal/gain inputs, 108 clean and 864 noisy controls, frozen specification and an exact clamped collision |
| `code/design_case/` | Twenty-observation coefficient-selection example in `ROWS.json` and `SUMMARY.json`; input/output specification included |
| `code/figure_sources/` | Standalone LaTeX sources and CSV inputs for Figures 1–4 |
| `code/animation/` | macOS renderer, formula cards, geometry/formula checks, and reproduction script |
| `docs/` | Angular enumeration procedure (PDF/LaTeX), implementation note, fixed-budget and calibration-error derivation (`DESIGN_ROBUSTNESS.pdf`/`.tex`), two-observation elimination and error certificate (`TWO_OBSERVATION_CALIBRATION.pdf`/`.tex`), and historical input-lineage record |

## Numerical reproduction

Python 3 and its standard library suffice. From the archive root, create a fresh working copy to preserve the bundled references, then run:

```sh
mkdir reproduced
cp -R code reproduced/code
python3 reproduced/code/run_validation.py
python3 reproduced/code/balanced_controls.py
python3 reproduced/code/prior_scope_controls/anisotropy_controls.py
python3 reproduced/code/angular_controls/angular_controls.py
python3 reproduced/code/residual_balance/residual_controls.py --spec code/residual_balance/SPEC.json --threshold code/threshold.csv --output reproduced/residual
python3 reproduced/code/design_case/design_case.py --output-dir reproduced/design
python3 code/budget_robustness/design_controls.py --spec code/budget_robustness/SPEC.json --output reproduced/budget_robustness
python3 code/budget_robustness/matched_comparison.py --rows reproduced/budget_robustness/ROWS.csv --output reproduced/budget_robustness/MATCHED_COMPARISON.json
python3 code/operating_band/verify_band_check.py --output reproduced/BAND_CHECK.json
python3 code/two_observation/two_observation_controls.py --spec code/two_observation/SPEC.json --output reproduced/two_observation
```

Expected reports are `PASS`, `BALANCED40_PASS`, `PASS`, and `PASS` for the first four commands. The angular report has 36 rows and 124 numerical assertions; exact rational root counts accompany numerical coefficient values (`kappa_interval_certified` is false). Its attempt marker permits one run per fresh working copy. Residual reproduction reports 21 rows, 17 curve points, maximum irradiance error `3E-80`, and maximum derivative discrepancy about `4.51E-25`. Compare `reproduced/residual/{ROWS.json,tolerance.csv,SUMMARY.json}` with `code/residual_balance/`. The design summary reports 20 rows, inverse constant 200, depth tolerance 0.02, and target satisfaction of 6/10 (threshold) versus 10/10 (margin); compare with `code/design_case/`. Output directories for the residual, design-case, and budget/robustness CLIs must be new.

The budget/robustness command reports `PASS`, 36 class–cap settings, 18 certified allocations, 18 uncertified settings and 3,456 controls (2,304 nominal-design and 1,152 robust-design observations). It writes `SUMMARY.json`, `CELLS.json`, `ROWS.csv`, `budget_curve.csv` (51 points), `mismatch_curve.csv` (61 points), and copies of `SPEC.json` and `design_controls.py` into `reproduced/budget_robustness/`; compare with `code/budget_robustness/`. The certificate uses exact rational arithmetic and the separate forward/inverse controls use 80 decimal digits. `docs/DESIGN_ROBUSTNESS.pdf` gives the derivation and interpretation. The declared caps are study inputs.

The isotropic report retains maximum 3D/reduced discrepancy about `1.11E-16`, maximum derivative discrepancy about `6.26E-10`, and both perturbation signs at all five magnitudes. The angular reference retains maximum irradiance discrepancy `2E-80` and derivative discrepancy about `7.50E-16`. Floating-point summaries should be compared numerically with the stated tolerances, rather than by file hash. The protocols and specifications list the conditions used in each calculation.

The paired-summary command matches both schemes on the same eighteen certified settings. Each has 1,152 controls; maximum depth errors are 0.032837 (nominal) and 0.014970 (certified), with four and zero target exceedances. It writes `MATCHED_COMPARISON.json`. Computed coefficients, depth errors and slopes in the paper use five significant figures; the JSON and CSV files retain full precision.

The operating-band command reports `BAND_CHECK_PASS`. It checks four exact root enclosures and derivative signs. The sufficient continuum condition is derived from manuscript Eq. (6).

The two-observation command reports `PASS`, 108 clean pairs and 864 noisy pairs. Geometry, source coefficients, relative weights and the emission exponent are calibrated; normal and gain are unknown but shared by both exposures. Balanced common-radius sources and nonnegative incidence yield the depth inverse. Each exposure has coefficient budget one, giving two across the pair. The decoder takes no normal, gain or true-depth inputs. At noise caps `1E-6` and `1E-4`, respectively, all 432 and 384/432 controls meet target 0.02; the observable bound certifies 432/432 and 216/432. All observed errors satisfy their individual bounds. `COLLISION.json` records distinct depths with identical intensities for every mixture of one fixed off-axis pattern and the coaxial source under partial clamping. All failed accuracy or certification cases remain in `NOISY_ROWS.csv`. The output directory must be new. `docs/TWO_OBSERVATION_CALIBRATION.pdf` gives the proofs. This is a separate study from the one-observation budget controls.

## Figures and animation

Compile each `figure1.tex`, `figure2.tex`, `figure3.tex`, and `figure4.tex` with `pdflatex -halt-on-error` from `code/figure_sources/` in the fresh copy. Required LaTeX packages include standalone, TikZ, and PGFplots. The adjacent CSV files are the plotted inputs. The manuscript and supplementary derivation tables also require siunitx. Figure 4 compares the sufficient coaxial fraction for the three layout classes: the left panel varies the normalized nominal margin, and the right panel varies the combined normal/gain cap at the fixed depth-error target 0.02. The shaded region marks settings for which this sufficient rule provides no certificate.

On macOS, run `zsh reproduce.sh` from `reproduced/code/animation/` with Swift, LaTeX, and FFmpeg installed. The script prints a new temporary directory containing `lighting_thresholds_3d.gif` and `lighting_thresholds_3d_silent.mp4`; its final checks report `FORMULA_CHECKS_PASSED` and `PASSED`. The animation illustrates the flat-normal model at 0.8, 1, and 1.2 times the threshold.

